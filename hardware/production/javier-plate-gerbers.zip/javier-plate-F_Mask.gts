G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-10-18T19:26:20+02:00*
G04 #@! TF.ProjectId,javier-plate,6a617669-6572-42d7-906c-6174652e6b69,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-18 19:26:20*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.000000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X81260000Y-98290000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X81260000Y-81790000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X120370000Y-118420000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X177080000Y-110330000D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X158440000Y-64130000D03*
G04 #@! TD*
M02*
